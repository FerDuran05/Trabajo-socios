package ar.org.centro35.herramientas.enums;

public enum HerramientaTipo {
    MANUAL,
    ELECTRICA,
    MEDICION,
    HIDRAULICA,
    NEUMATICA
}
