
package ar.org.centro35.herramientas.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ar.org.centro35.herramientas.entities.socios;
import ar.org.centro35.herramientas.enums.TipoDocumento;
import ar.org.centro35.herramientas.repositories.SocioRepository;

@Controller
public class SocioController {

    @Autowired
    private SocioRepository socioRepository;

    private String mensajeSocio = "Ingrese un nuevo socio";

    @GetMapping("/socios")
    public String getSocios(@RequestParam(name = "buscar", defaultValue = "", required = false) String buscar,
            Model model) {
        model.addAttribute("tipos", TipoDocumento.values());
        model.addAttribute("mensajeSocio", mensajeSocio);
        model.addAttribute("socio", new socios(null, null, null, null, null, null, null, null, null));
        model.addAttribute("socios", socioRepository.findByNombreContainingIgnoreCase(buscar));
        return "socios";
    }

    @PostMapping("/sociosSave")
    public String sociosSave(@ModelAttribute socios socio) {
        try {
            socioRepository.save(socio);
            if (socio.getId() > 0) {
                mensajeSocio = "Se guardó el socio con ID: " + socio.getId();
            } else {
                mensajeSocio = "No se pudo guardar el socio";
            }
        } catch (Exception e) {
            mensajeSocio = "Ocurrió un error al guardar el socio";
        }
        return "redirect:socios";
    }

    @PostMapping("/sociosRemove")
    public String sociosRemove(@RequestParam(name = "idBorrar", defaultValue = "0", required = false) Long idBorrar) {
        try {
            socioRepository.deleteById(idBorrar);
            mensajeSocio = "Se borró el socio con ID: " + idBorrar;
        } catch (Exception e) {
            mensajeSocio = "No se pudo borrar el socio con ID: " + idBorrar;
        }
        return "redirect:socios";
    }
}