package ar.org.centro35.herramientas.enums;

public enum PrestamoEstado {
    PENDIENTE,
    TERMINADO
}
