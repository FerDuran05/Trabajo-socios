package ar.org.centro35.herramientas.entities;

public class Prestamo {
    
}
