package ar.org.centro35.herramientas.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ar.org.centro35.herramientas.entities.Herramienta;
import ar.org.centro35.herramientas.enums.HerramientaEstado;
import ar.org.centro35.herramientas.repositories.HerramientaRepository;

@RestController
@RequestMapping("/api/herramientas/v1")
public class HerramientasServices {

    @Autowired
    private HerramientaRepository hr;

    @RequestMapping(value="", method=RequestMethod.GET, produces = "text/html")
    public String getIndex(){
        return "<h1>Servicio Web Activo!</h1>";
    }


    @GetMapping("/herramientas")
    public List<Herramienta>getAll(){
        return ((List<Herramienta>)hr.findAll())
                    .stream()
                    .filter(h->h.getHerramienta_estado()!=HerramientaEstado.FUERA_DE_USO)
                    .toList();
    }

    @GetMapping("/herramientas/{descripcion}")
	public List<Herramienta>getLikeDescripcion(@PathVariable String descripcion) {
		return ((List<Herramienta>)hr.findAll())
                    .stream()
                    .filter(h->h.getDescripcion().toLowerCase().contains(descripcion.toLowerCase()))
                    .filter(h->h.getHerramienta_estado()!=HerramientaEstado.FUERA_DE_USO)
                    .toList();
	}

}
