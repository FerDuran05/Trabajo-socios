package ar.org.centro35.herramientas.enums;

public enum TipoDocumento {
    DNI,
    LC,
    LE,
    CI,
    PASS
}
