package ar.org.centro35.herramientas.repositories;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ar.org.centro35.herramientas.entities.socios;
@Repository
public interface SocioRepository extends CrudRepository<socios, Long> {
    public abstract List<socios> findByNombreContainingIgnoreCase(String nombre);
}